"""
StabilizedCrop - fixed-resolution stabilized crop for AI inpainting round trips.
================================================================================

Builds a single Group node that does exactly two things:

  input 0  plate      the footage
  input 1  roto       Roto / RotoPaint, sampled by Analyze for its bounding box
  input 2  result     the sequence that comes back from ComfyUI

  mode = crop         output is a fixed WxH stabilized crop of the plate
  mode = uncrop       output is the result put back where it came from, at
                      plate resolution

Nothing else. The roto is only ever read by Analyze - it does not touch the
picture, so the crop carries whatever channels the plate carries and the uncrop
carries whatever the result carries. Both modes pass pixels straight through.

There is no compositing and no matte handling. Uncrop is the exact inverse of
crop, so you merge the reconstruction over your plate downstream, through
whatever matte the shot actually needs.

For the mask that goes out alongside the crop, copy this node and plug the roto
into the copy's plate input. The cached bbox and the solve are identical, so the
mask lines up with the picture exactly.

The bbox is sampled once from the roto control points (no rendering) and cached
on hidden animated knobs, so changing the crop resolution re-solves instantly.

Every transform in both directions is an integer pixel translation with an
impulse filter, so the crop -> uncrop round trip is pixel exact.

Usage
-----
    import stabilized_crop
    stabilized_crop.create()          # or register_menu() once in menu.py

Then plug in plate + roto, press "Analyze roto", set the resolution, and render
the output with mode = crop.

Self-contained - this is the only file you need to deploy. Targets Nuke 15.x /
16.x.
"""

import math

import nuke
import nuke.rotopaint as rp

# Bump on release, and tag the repo to match.
#   patch  behaviour fixes inside existing functions. Reach nodes already saved
#          in scripts, because the buttons import this module at click time.
#   minor  anything touching _build_internals or _add_knobs. Nodes already saved
#          keep their old internals and need rebuilding to pick it up.
#   major  the node's contract changes, so a rebuilt node behaves differently
#          from the one it replaces, or a public name moves and saved nodes
#          break outright.
__version__ = "3.0.0"

MENU_LABEL = "Stabilized Crop (fixed res)"
SUBMENU_LABEL = "Convert"

# Common latent-friendly buckets. "custom" leaves res_w / res_h alone.
RES_PRESETS = [
    "custom",
    "512 x 512",
    "768 x 768",
    "1024 x 1024",
    "1152 x 896",
    "896 x 1152",
    "1216 x 832",
    "832 x 1216",
    "1344 x 768",
    "768 x 1344",
    "1536 x 1536",
    "2048 x 2048",
]

MODES = ["crop", "uncrop"]

# "Set res to fit bbox" rounds up to a multiple of this. Latent diffusion models
# work on an 8x downsampled latent and most UNets downsample a further 8x, so
# dimensions off a multiple of 32 get silently padded or rejected. Every entry in
# RES_PRESETS above is already a multiple of 64.
RES_STEP = 32


# ---------------------------------------------------------------------------
# World-space roto bbox math, inlined verbatim from roto_to_bbox.py so this
# module ships as a single file. If you fix the bbox math there, port it here.
# ---------------------------------------------------------------------------

def bvfx_roto_walker(rotoNode, rotoList=None):
    """Traverse the roto node hierarchy tree and generate a list with [element, parent].

    Ignores Strokes. Handles both a Roto/RotoPaint Node (top-level) and
    a Layer (recursive).

    Returns:
        list of (Shape|Layer, parentLayer)
    """
    if rotoList is None:
        rotoList = []

    try:
        if rotoNode.Class() in ("Roto", "RotoPaint"):
            rotoRoot = rotoNode["curves"].rootLayer
            rotoList = []
    except Exception:
        rotoRoot = rotoNode

    for layer in rotoRoot:
        if isinstance(layer, rp.Shape):
            rotoList.append((layer, rotoRoot))
        if isinstance(layer, rp.Layer):
            rotoList.append((layer, rotoRoot))
            bvfx_roto_walker(layer, rotoList)
    return rotoList


def bvfx_TTM(point, transf, frame):
    """Apply a Transform's extra matrix to a point (Transform To Matrix).

    Args:
        point: (x, y) tuple
        transf: Transform with evaluate(frame).getMatrix() method
        frame: frame to evaluate
    Returns:
        (x, y, z) tuple in transformed space
    """
    matrix = transf.evaluate(frame).getMatrix()
    vector = nuke.math.Vector4(point[0], point[1], 1, 1)
    x = (vector[0] * matrix[0]) + (vector[1] * matrix[1]) + matrix[2] + matrix[3]
    y = (vector[0] * matrix[4]) + (vector[1] * matrix[5]) + matrix[6] + matrix[7]
    z = (vector[0] * matrix[8]) + (vector[1] * matrix[9]) + matrix[10] + matrix[11]
    w = (vector[0] * matrix[12]) + (vector[1] * matrix[13]) + matrix[14] + matrix[15]
    vector = nuke.math.Vector4(x, y, z, w)
    vector = vector / w
    return vector


def bvfx_TL(point, Layer, frame, shapeList):
    """Recursively apply Layers' matrix/transforms on a point up to roto.root.

    Args:
        point: (x, y) tuple
        Layer: the layer to apply the transform from
        frame: frame to evaluate
        shapeList: result of bvfx_roto_walker()
    Returns:
        (x, y, z) tuple
    """
    newPoint = bvfx_TTM(point, Layer.getTransform(), frame)

    # shapeList[0][1] always holds roto.root, so we stop at the root
    if not Layer == shapeList[0][1]:
        for s in shapeList:
            if s[0] is Layer:
                newPoint = bvfx_TL(newPoint, s[1], frame, shapeList)
                break
    return newPoint


def compute_baked_bbox_at_frame(shapeList, frame):
    """Compute the bounding box of all shapes in the walker list at a given frame.

    Transforms from extra matrix (getTransform) and parent layers (via bvfx_TL)
    are applied to every control point position before computing bounds.

    Args:
        shapeList: result of bvfx_roto_walker()
        frame: frame to evaluate

    Returns:
        (min_x, min_y, max_x, max_y) or None if no visible shapes
    """
    min_x = float("inf")
    min_y = float("inf")
    max_x = float("-inf")
    max_y = float("-inf")
    found = False

    for shape, parentLayer in shapeList:
        if not isinstance(shape, rp.Shape):
            continue

        # Get the shape's local transform (includes extra matrix from Roto/Transform)
        try:
            transf = shape.getTransform()
        except Exception:
            transf = None

        for cp in shape:
            # Get the raw position of this CV
            curve_x = cp.center.getPositionAnimCurve(0)
            curve_y = cp.center.getPositionAnimCurve(1)
            raw_x = curve_x.evaluate(frame)
            raw_y = curve_y.evaluate(frame)

            # Apply shape's local transform (extra matrix)
            if transf is not None:
                baked_point = bvfx_TTM((raw_x, raw_y), transf, frame)
            else:
                baked_point = (raw_x, raw_y, 0)

            # Apply parent layer transforms recursively
            if parentLayer is not None:
                final = bvfx_TL((baked_point[0], baked_point[1]), parentLayer, frame, shapeList)
            else:
                final = baked_point

            px, py = final[0], final[1]
            if px < min_x:
                min_x = px
            if py < min_y:
                min_y = py
            if px > max_x:
                max_x = px
            if py > max_y:
                max_y = py
            found = True

    if not found:
        return None

    return (min_x, min_y, max_x, max_y)


# ---------------------------------------------------------------------------
# bbox sampling
# ---------------------------------------------------------------------------

def _sample_bbox(roto_node, first, last):
    """Sample the roto bbox for every frame in the range.

    Returns [(frame, x, y, r, t), ...] using the same control-point + matrix
    math as roto_to_bbox, so no rendering is needed.
    """
    shape_list = bvfx_roto_walker(roto_node)
    if not shape_list:
        raise ValueError("no shapes found inside '{}'".format(roto_node.name()))

    samples = []
    total = max(1, last - first + 1)
    task = nuke.ProgressTask("Sampling roto bbox")
    try:
        for i, frame in enumerate(range(first, last + 1)):
            if task.isCancelled():
                raise RuntimeError("cancelled")
            task.setProgress(int(100.0 * i / total))
            task.setMessage("Frame {}".format(frame))

            box = compute_baked_bbox_at_frame(shape_list, frame)
            if box is None:
                continue
            samples.append((frame, box[0], box[1], box[2], box[3]))
    finally:
        del task

    if not samples:
        raise ValueError("roto produced no bbox over frames {}-{}".format(first, last))
    return samples


def _store_bbox(node, samples):
    """Bake sampled bboxes onto the node's hidden animated knobs."""
    for knob_name in ("bbox_lo", "bbox_hi"):
        knob = node[knob_name]
        knob.clearAnimated()
        knob.setAnimated()

    lo = node["bbox_lo"]
    hi = node["bbox_hi"]
    for frame, x, y, r, t in samples:
        # floor the low corner and ceil the high corner so the integer box
        # always fully contains the shape
        lo.setValueAt(float(math.floor(x)), frame, 0)
        lo.setValueAt(float(math.floor(y)), frame, 1)
        hi.setValueAt(float(math.ceil(r)), frame, 0)
        hi.setValueAt(float(math.ceil(t)), frame, 1)


def _read_bbox(node):
    """Read the cached bboxes back off the hidden knobs.

    Returns [(frame, x, y, r, t), ...] or [] if the node has not been analyzed.
    """
    lo = node["bbox_lo"]
    hi = node["bbox_hi"]
    if not lo.isAnimated(0):
        return []

    frames = sorted(int(round(key.x)) for key in lo.animation(0).keys())
    boxes = []
    for frame in frames:
        boxes.append((
            frame,
            int(round(lo.valueAt(frame, 0))),
            int(round(lo.valueAt(frame, 1))),
            int(round(hi.valueAt(frame, 0))),
            int(round(hi.valueAt(frame, 1))),
        ))
    return boxes


# ---------------------------------------------------------------------------
# window solve
# ---------------------------------------------------------------------------

def _child(group, name):
    """Return the group's internal node called *name*."""
    for node in group.nodes():
        if node.name() == name:
            return node
    raise ValueError("'{}' has no internal node named '{}'".format(group.name(), name))


def _live_plate_size(node):
    """Format size of the plate input right now, or the project format."""
    plate = node.input(0)
    if plate is not None:
        try:
            fmt = plate.format()
            if fmt is not None and fmt.width() > 0 and fmt.height() > 0:
                return int(fmt.width()), int(fmt.height())
        except Exception:
            pass
    fmt = nuke.root().format()
    return int(fmt.width()), int(fmt.height())


def _store_plate_size(node, width, height):
    """Record the plate format the analysis was solved against."""
    knob = node["plate_size"]
    knob.setValue(float(width), 0)
    knob.setValue(float(height), 1)


def _read_plate_cache(node):
    """Plate size recorded at Analyze time, or None if there isn't one.

    Returns None for nodes built before this knob existed so they keep working
    on the old live-input behaviour rather than erroring.
    """
    knob = node.knob("plate_size")
    if knob is None:
        return None
    width, height = int(knob.value(0)), int(knob.value(1))
    if width < 1 or height < 1:
        return None
    return width, height


def _plate_size(node):
    """Plate size for the solve. Returns (width, height, warning).

    Prefers the size recorded at Analyze time over the live input. Plate size
    only enters the math through clamping, but that is enough: without the
    cache, disconnecting the plate falls back to the project format and
    silently re-bakes the transforms against the wrong numbers. The cache never
    changes on its own, so the bake can only move when Analyze is pressed.
    """
    cached = _read_plate_cache(node)
    if cached is None:
        width, height = _live_plate_size(node)
        return width, height, ""

    warning = ""
    if node.input(0) is not None and _live_plate_size(node) != cached:
        live_w, live_h = _live_plate_size(node)
        warning = ("! plate is {} x {} but was analyzed at {} x {}"
                   " - press Analyze roto".format(live_w, live_h, *cached))
    return cached[0], cached[1], warning


def _read_offsets(node, frames):
    """Per-frame crop offset as {frame: (dx, dy)}, or None if there is none.

    Read with valueAt so animating the offset works. Any per-frame integer
    shift stays pixel exact, because the window position it produces drives
    both directions of the round trip.

    Returns None for nodes built before these knobs existed, and also when the
    offset is zero everywhere, so an unused offset changes nothing.
    """
    x_knob, y_knob = node.knob("offset_x"), node.knob("offset_y")
    if x_knob is None or y_knob is None:
        return None

    offsets = {}
    for frame in frames:
        offsets[frame] = (int(round(x_knob.valueAt(frame))),
                          int(round(y_knob.valueAt(frame))))
    if not any(dx or dy for dx, dy in offsets.values()):
        return None
    return offsets


def _result_warning(node, res_w, res_h):
    """Flag a result input that cannot be put back the way it went out.

    Silent in crop mode, where the result input is not read at all and an empty
    one is the normal state while the crop is still out at the model.

    In uncrop mode an empty result input is worth saying out loud. The node
    still renders, as an empty plate-sized frame, which reads as a broken node
    rather than as a missing input.

    A patch that is the wrong size is placed anyway, at whatever size it is,
    because guessing the intent would mean resampling and that is the one thing
    this node never does.
    """
    if node["mode"].value() != "uncrop":
        return ""
    result = node.input(2)
    if result is None:
        return "! nothing connected to the result input"
    try:
        fmt = result.format()
        width, height = int(fmt.width()), int(fmt.height())
    except Exception:
        return ""
    if width < 1 or height < 1 or (width, height) == (res_w, res_h):
        return ""
    return "! result is {} x {}, crop was {} x {}".format(
        width, height, res_w, res_h)


def _solve_windows(boxes, res_w, res_h, plate_w, plate_h, offsets=None):
    """Place a fixed res_w x res_h window on the bbox centre of every frame.

    The window is clamped to stay inside the plate, so near the frame edges the
    element drifts within the crop rather than pulling in off-plate pixels. If
    the window is wider or taller than the plate it is centred instead, which is
    the only case that can introduce black.

    offsets shifts the window, as {frame: (dx, dy)}. It is applied before the
    clamp, so the crop still cannot leave the plate; frames where the plate edge
    absorbed some of the shift come back in held_frames. Integer only, which is
    what keeps the round trip pixel exact.

    Returns (windows, clipped_frames, held_frames) where
        windows        - [(frame, win_x, win_y), ...] integer lower-left corners
        clipped_frames - frames whose bbox does not fit inside its window
        held_frames    - frames where the plate edge limited a nonzero offset
    """
    def _place(lo, hi, size, plate_size, offset):
        """Returns (origin, was_clamped)."""
        centre = int(round((lo + hi) * 0.5))
        origin = centre - size // 2 + offset
        if size <= plate_size:
            limited = max(0, min(plate_size - size, origin))
            return limited, limited != origin
        # window bigger than the plate: centre it and accept the overscan
        return (plate_size - size) // 2 + offset, False

    windows = []
    clipped = []
    held = []
    for frame, x, y, r, t in boxes:
        off_x, off_y = offsets.get(frame, (0, 0)) if offsets else (0, 0)
        win_x, held_x = _place(x, r, res_w, plate_w, off_x)
        win_y, held_y = _place(y, t, res_h, plate_h, off_y)
        windows.append((frame, win_x, win_y))
        if x < win_x or y < win_y or r > win_x + res_w or t > win_y + res_h:
            clipped.append(frame)
        if (off_x and held_x) or (off_y and held_y):
            held.append(frame)
    return windows, clipped, held


def _bbox_extremes(boxes):
    """Return (max_w, max_h) of the largest single-frame bbox."""
    max_w = max(r - x for _, x, _y, r, _t in boxes)
    max_h = max(t - y for _, _x, y, _r, t in boxes)
    return max_w, max_h


# ---------------------------------------------------------------------------
# writing the solve into the group
# ---------------------------------------------------------------------------

def _bake_translate(transform, values):
    """Set Transform.translate from [(frame, tx, ty), ...] as integers."""
    knob = transform["translate"]
    knob.clearAnimated()
    knob.setAnimated()
    for frame, tx, ty in values:
        knob.setValueAt(float(int(tx)), frame, 0)
        knob.setValueAt(float(int(ty)), frame, 1)


def _apply(node):
    """Re-solve the crop window from the cached bbox and push it into the group.

    Cheap - no roto sampling - so this can run on every knob change.
    """
    boxes = _read_bbox(node)
    if not boxes:
        node["report_bbox"].setValue("bbox: press Analyze roto")
        node["report_clip"].setValue("")
        return

    res_w = int(node["res_w"].value())
    res_h = int(node["res_h"].value())
    if res_w < 1 or res_h < 1:
        node["report_clip"].setValue("! resolution must be at least 1 x 1")
        return

    plate_w, plate_h, plate_warning = _plate_size(node)
    offsets = _read_offsets(node, [frame for frame, _x, _y, _r, _t in boxes])
    windows, clipped, held = _solve_windows(
        boxes, res_w, res_h, plate_w, plate_h, offsets)

    # Frame 1 of the solve defines the static crop box; every other frame is
    # translated so its window lands on that same box.
    ref_x, ref_y = windows[0][1], windows[0][2]

    stabilize = [(frame, ref_x - win_x, ref_y - win_y) for frame, win_x, win_y in windows]
    matchmove = [(frame, win_x - ref_x, win_y - ref_y) for frame, win_x, win_y in windows]

    _bake_translate(_child(node, "Stabilize"), stabilize)
    _bake_translate(_child(node, "Matchmove"), matchmove)

    crop = _child(node, "CropWindow")
    crop_box = crop["box"]
    crop_box.clearAnimated()
    for index, value in enumerate((ref_x, ref_y, ref_x + res_w, ref_y + res_h)):
        crop_box.setValue(float(value), index)

    place = _child(node, "ResultPlace")
    place["translate"].clearAnimated()
    place["translate"].setValue(float(ref_x), 0)
    place["translate"].setValue(float(ref_y), 1)

    # The uncrop has to come out plate-sized, not crop-sized with an offset.
    frame_box = _child(node, "PlateFrame")["box"]
    frame_box.clearAnimated()
    for index, value in enumerate((0, 0, plate_w, plate_h)):
        frame_box.setValue(float(value), index)

    # report
    max_w, max_h = _bbox_extremes(boxes)
    node["report_bbox"].setValue(
        "max bbox: {} x {} px     travel: {} x {} px".format(
            max_w, max_h,
            max(r for _f, _x, _y, r, _t in boxes) - min(x for _f, x, _y, _r, _t in boxes),
            max(t for _f, _x, _y, _r, t in boxes) - min(y for _f, _x, y, _r, _t in boxes),
        )
    )

    warnings = []
    if plate_warning:
        warnings.append(plate_warning)
    if clipped:
        warnings.append("! bbox clipped on {} of {} frames (first {})".format(
            len(clipped), len(boxes), clipped[0]))
    if held:
        warnings.append("! offset limited by plate edge on {} of {} frames".format(
            len(held), len(boxes)))
    if res_w > plate_w or res_h > plate_h:
        warnings.append("! res exceeds plate {} x {} - edges will be black".format(
            plate_w, plate_h))
    result_warning = _result_warning(node, res_w, res_h)
    if result_warning:
        warnings.append(result_warning)
    node["report_clip"].setValue("     ".join(warnings))


# ---------------------------------------------------------------------------
# button / callback entry points
# ---------------------------------------------------------------------------

def analyze(node):
    """Sample the roto bbox over the range, cache it, then re-solve."""
    roto = node.input(1)
    if roto is None:
        nuke.message("Connect a Roto or RotoPaint to the 'roto' input.")
        return
    # The window is clamped to the plate, so the solve is only meaningful with
    # a plate to measure. Refusing here also keeps a project-format guess from
    # being cached as though it were the real thing.
    if node.input(0) is None:
        nuke.message("Connect the plate to the 'plate' input before analyzing.")
        return
    if roto.Class() not in ("Roto", "RotoPaint"):
        nuke.message("'{}' is a {} - the roto input needs a Roto or RotoPaint.".format(
            roto.name(), roto.Class()))
        return

    first = int(node["first"].value())
    last = int(node["last"].value())
    if last < first:
        nuke.message("Last frame is before first frame.")
        return

    try:
        samples = _sample_bbox(roto, first, last)
    except RuntimeError:
        return
    except ValueError as error:
        nuke.message(str(error))
        return

    _store_bbox(node, samples)
    _store_plate_size(node, *_live_plate_size(node))
    _apply(node)


def _version_label():
    """Text stamped onto a node when it is built."""
    return "StabilizedCrop v{}".format(__version__)


def _round_up(size, step=None):
    """Smallest multiple of step that is >= size."""
    step = RES_STEP if step is None else step
    return int(math.ceil(size / float(step)) * step)


def fit_res(node):
    """Round the resolution up to contain the largest bbox, in steps of RES_STEP."""
    boxes = _read_bbox(node)
    if not boxes:
        nuke.message("Press 'Analyze roto' first.")
        return
    max_w, max_h = _bbox_extremes(boxes)
    node["res_w"].setValue(_round_up(max_w))
    node["res_h"].setValue(_round_up(max_h))
    node["res_preset"].setValue("custom")
    _apply(node)


def on_knob_changed():
    """knobChanged handler installed on the group."""
    node = nuke.thisNode()
    knob = nuke.thisKnob()
    name = knob.name()

    if name == "res_preset":
        value = knob.value()
        if value != "custom":
            width, height = value.split(" x ")
            node["res_w"].setValue(int(width))
            node["res_h"].setValue(int(height))
        _apply(node)
    elif name in ("res_w", "res_h"):
        node["res_preset"].setValue("custom")
        _apply(node)
    elif name in ("inputChange", "first", "last", "offset_x", "offset_y", "mode"):
        # "mode" changes nothing in the solve, but the result input is only
        # reported on in uncrop mode, so flipping modes has to refresh it.
        _apply(node)


# ---------------------------------------------------------------------------
# node construction
# ---------------------------------------------------------------------------

def _add_knobs(group):
    """Build the group's user interface."""
    first_frame = int(nuke.root()["first_frame"].value())
    last_frame = int(nuke.root()["last_frame"].value())

    def add(knob, tooltip=None, same_line=False, invisible=False):
        if tooltip:
            knob.setTooltip(tooltip)
        if same_line:
            knob.clearFlag(nuke.STARTLINE)
        if invisible:
            knob.setFlag(nuke.INVISIBLE)
        group.addKnob(knob)
        return knob

    add(nuke.Text_Knob("div_analyze", "bounding box"))

    add(nuke.Int_Knob("first", "range"),
        "First frame to sample the roto over.")
    add(nuke.Int_Knob("last", ""),
        "Last frame to sample the roto over.", same_line=True)
    group["first"].setValue(first_frame)
    group["last"].setValue(last_frame)

    add(nuke.PyScript_Knob(
        "analyze", "Analyze roto",
        "import stabilized_crop; stabilized_crop.analyze(nuke.thisNode())"),
        "Sample the roto bbox on every frame in the range and cache it on this "
        "node. Run again after editing the roto shapes.")

    add(nuke.Text_Knob("report_bbox", ""))
    add(nuke.Text_Knob("report_clip", ""))

    add(nuke.Text_Knob("div_res", "crop resolution"))

    add(nuke.Enumeration_Knob("res_preset", "preset", RES_PRESETS),
        "Common model resolutions. Choosing one sets the width and height below.")
    add(nuke.Int_Knob("res_w", "resolution"),
        "Crop width in pixels. The plate is not rescaled - this is the size of "
        "the window cut out of it.")
    add(nuke.Int_Knob("res_h", ""),
        "Crop height in pixels.", same_line=True)
    group["res_w"].setValue(1024)
    group["res_h"].setValue(1024)

    add(nuke.PyScript_Knob(
        "fit_res", "Set res to fit bbox",
        "import stabilized_crop; stabilized_crop.fit_res(nuke.thisNode())"),
        "Round the resolution up to the next multiple of {} that contains the "
        "largest bbox, so nothing is clipped.".format(RES_STEP))

    add(nuke.Int_Knob("offset_x", "offset"),
        "Shift the crop window right by this many pixels. Applied before the "
        "clamp, so the crop still cannot leave the plate - the report says when "
        "a plate edge is limiting it. Animatable.")
    add(nuke.Int_Knob("offset_y", ""),
        "Shift the crop window up by this many pixels.", same_line=True)

    add(nuke.Text_Knob("div_out", "output"))

    add(nuke.Enumeration_Knob("mode", "mode", MODES),
        "crop: the stabilized crop of the plate, to render out to ComfyUI.\n"
        "uncrop: the 'result' input put back where it came from, at plate "
        "resolution. Merge it over your plate yourself downstream.")

    # Stamped once, at build time, and never updated. Names the version that
    # built this node, which is not necessarily the version now installed:
    # behaviour changes reach old nodes, structural ones do not. Called
    # tool_version rather than version because some node classes already have
    # a knob by that name.
    add(nuke.Text_Knob("tool_version", "", _version_label()),
        "Version of stabilized_crop.py that built this node. Compare with "
        "stabilized_crop.__version__ to see what is installed.")

    # cached per-frame bbox, hidden but saved with the script
    add(nuke.XY_Knob("bbox_lo", "bbox lo"), invisible=True)
    add(nuke.XY_Knob("bbox_hi", "bbox hi"), invisible=True)
    add(nuke.XY_Knob("plate_size", "plate size"), invisible=True)


def _build_internals(group):
    """Create the node tree inside the group."""
    group.begin()
    try:
        plate = nuke.nodes.Input(name="plate", number=0, xpos=0, ypos=0)

        # Deliberately feeds nothing. Analyze reads the shapes off this input
        # directly, in Python, so the roto never enters the picture tree.
        nuke.nodes.Input(name="roto", number=1, xpos=200, ypos=0)

        result = nuke.nodes.Input(name="result", number=2, xpos=400, ypos=0)

        # --- crop branch ------------------------------------------------------
        # The plate, translated so the bbox centre sits still, then cut to the
        # requested resolution. Whatever channels the plate carries come through
        # untouched.
        stabilize = nuke.nodes.Transform(
            name="Stabilize", inputs=[plate], xpos=0, ypos=180,
            filter="impulse", label="lock bbox centre")

        crop = nuke.nodes.Crop(
            name="CropWindow", inputs=[stabilize], xpos=0, ypos=260,
            crop=True, reformat=True, label="[value parent.res_w] x [value parent.res_h]")

        # --- uncrop branch ----------------------------------------------------
        # The exact inverse of the crop, and nothing else. No compositing and no
        # matte: the output is the patch back at its original position in a
        # plate-sized frame, so the artist merges it downstream however the shot
        # needs.
        place = nuke.nodes.Transform(
            name="ResultPlace", inputs=[result], xpos=400, ypos=180,
            filter="impulse", label="back into stabilized space")

        matchmove = nuke.nodes.Transform(
            name="Matchmove", inputs=[place], xpos=400, ypos=260,
            filter="impulse", label="back into plate space")

        # The result input carries the crop's format, so without this the
        # uncrop would come out crop-sized with the pixels merely offset.
        # _apply sets the box to the analyzed plate size.
        frame = nuke.nodes.Crop(
            name="PlateFrame", inputs=[matchmove], xpos=400, ypos=340,
            crop=True, reformat=True, label="back to plate format")

        # --- output -----------------------------------------------------------
        mode_switch = nuke.nodes.Switch(
            name="OutSwitch", inputs=[crop, frame], xpos=0, ypos=440)
        mode_switch["which"].setExpression("parent.mode")

        nuke.nodes.Output(inputs=[mode_switch], xpos=0, ypos=510)
    finally:
        group.end()


def create():
    """Create and return a configured StabilizedCrop group."""
    selected = nuke.selectedNodes()
    group = nuke.createNode("Group", inpanel=False)
    group.setName("StabilizedCrop1")
    group["tile_color"].setValue(0x2277BBFF)

    _build_internals(group)
    _add_knobs(group)

    group["knobChanged"].setValue(
        "import stabilized_crop; stabilized_crop.on_knob_changed()")

    # Convenience: wire up a selection. Roto/RotoPaint always goes to the roto
    # input, since nuke.selectedNodes() order is not the selection order.
    rotos = [n for n in selected if n.Class() in ("Roto", "RotoPaint")]
    plates = [n for n in selected if n not in rotos]
    if plates:
        group.setInput(0, plates[0])
    if rotos:
        group.setInput(1, rotos[0])

    _apply(group)
    return group


def register_menu(menu_path=SUBMENU_LABEL, shortcut=""):
    """Add the tool to the Nuke node menu. Call once from a menu.py.

    menu_path may be nested with slashes, so a facility deploy can drop it into
    an existing studio menu:

        stabilized_crop.register_menu("MyStudio/Roto")
    """
    menu = nuke.menu("Nodes").addMenu(menu_path)
    menu.addCommand(
        MENU_LABEL,
        "import stabilized_crop; stabilized_crop.create()",
        shortcut)


if __name__ == "__main__":
    create()
